#TODO
-Add missing commands NO AESni version
-Add AESni Support for AMD

-Make the same code in a NO shell version but command line params like keyhunt
