# libaesni
Advanced Encryption Standard (AES) library using Intel AES-NI
